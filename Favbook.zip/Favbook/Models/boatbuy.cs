﻿namespace Favbook.Models
{
    public class boatbuy
    {
         
        public int id { get; set; }

         public string rentername { get; set; }
        public string RENTEDrname { get; set; }
        public string boattype { get; set; }
        public string renttime { get; set; }
        public string describtion { get; set; }
        public string url { get; set; }
        public boatbuy()
        {
             
        }
    }
}
